#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

sleep 2

# Power Effisien
chmod 0755 /sys/module/workqueue/parameters/power_efficient
echo Y > /sys/kernel/fast_charge/force_fast_charge/power_efficient
chmod 0444 /sys/module/workqueue/parameters/power_efficient

sleep 3

# Fix GMS Disable...
su -c pm disable com.google.android.gms/.chimera.GmsIntentOperationService
su -c pm disable com.google.android.apps.messaging/.shared.analytics.recurringmetrics..AnalyticsAlarmReceiver
su -c pm disable com.google.android.location.internal.UPLOAD_ANALYTICS
su -c pm disable com.facebook.orca/com.facebook.analytics.apptatelogger.AppStateIntentService
su -c pm disable com.facebook.orca/com.facebook.analytics2.Logger.LollipopUploadService
su -c pm disable com.google.android.gms/com.google.android.gms.nearby.bootstrap.service.NearbyBootstrapService
su -c pm disable com.google.android.gms/NearbyMessagesService
su -c pm disable com.google.android.gms/com.google.android.gms.nearby.connection.service.NearbyConnectionsAndroidService
su -c pm disable com.google.android.gms/com.google.location.nearby.direct.service.NearbyDirectService
su -c pm disable com.google.android.gms/com.google.android.gms.lockbox.LockboxService
su -c pm disable com.google.android.gms/.measurement.PackageMeasurementTaskService
su -c pm disable com.google.android.gms/com.google.android.gms.auth.trustagent.GoogleTrustAgent
su -c pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsTaskService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.cache.CacheBrokerService
su -c pm disable com.google.android.gms/com.android.billingclient.api.ProxyBillingActivity
su -c pm disable com.google.android.gms/com.google.android.gms.ads.measurement.GmpConversionTrackingBrokerService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.config.FlagsReceiver
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.service.MeasurementBrokerService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.adinfo.AdvertisinglnfoContentProvider
su -c pm disable com.google.android.gms/com.google.android.gms.ads.AdRequestBrokerService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.jams.NegotiationService
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.PackageMeasurementService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.social.GcmSchedulerWakeupService
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.PackageMeasurementTaskService
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.PackageMeasurementReceiver
su -c pm disable com.google.android.gms/com.google.android.gms.ads.identifier.service.AdvertisingldService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.GservicesValueBrokerService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.settings.AdsSettingsActivity
su -c pm disable com.google.android.gms/com.google.android.gms.ads.identifier.service.AdvertisingldNotificationService
